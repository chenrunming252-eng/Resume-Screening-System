from flask import Flask, render_template, request

app = Flask(__name__)
app.config['MAX_CONTENT_LENGTH'] = 32 * 1024


@app.get('/')
def index():
    return render_template('index.html')


@app.post('/api/messages')
def receive_message():
    if not request.is_json:
        return {'error': '请以 JSON 格式提交内容。'}, 415
    payload = request.get_json()
    if not isinstance(payload, dict) or not isinstance(payload.get('message'), str):
        return {'error': 'message 必须是字符串。'}, 400
    text = payload['message'].strip()
    if not 1 <= len(text) <= 6000:
        return {'error': '请输入 1–6000 个字符的经历。'}, 400
    # 当前只接收，不调用模型或保存；后续在这里接入会话服务。
    return {'message': text, 'stage': 'received'}


@app.errorhandler(400)
def invalid_json(error):
    return {'error': '请求内容不是有效的 JSON。'}, 400


@app.errorhandler(413)
def request_too_large(error):
    return {'error': '请求体超过 32 KiB，请缩短内容。'}, 413
