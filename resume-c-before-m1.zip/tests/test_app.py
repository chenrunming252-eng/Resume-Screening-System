import json
import unittest

from app import app


class MessageInputTests(unittest.TestCase):
    def setUp(self):
        self.client = app.test_client()

    def test_valid_message_preserves_facts_and_trims_outer_whitespace(self):
        response = self.client.post('/api/messages', json={'message': '  负责 Python 后端。\n实现搜索。  '})
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json, {'message': '负责 Python 后端。\n实现搜索。', 'stage': 'received'})

    def test_invalid_input_shapes_are_rejected(self):
        for payload in ([], None, {}, {'message': None}, {'message': 123}, {'message': []}):
            with self.subTest(payload=payload):
                response = self.client.post('/api/messages', data=json.dumps(payload), content_type='application/json')
                self.assertEqual(response.status_code, 400)
                self.assertIn('error', response.json)

    def test_blank_messages_are_rejected(self):
        for text in ('', ' \n\t', '\u3000'):
            with self.subTest(text=text):
                response = self.client.post('/api/messages', json={'message': text})
                self.assertEqual(response.status_code, 400)

    def test_message_length_boundary(self):
        for size, expected in ((6000, 200), (6001, 400)):
            with self.subTest(size=size):
                response = self.client.post('/api/messages', json={'message': 'a' * size})
                self.assertEqual(response.status_code, expected)

    def test_malformed_json_has_a_json_error(self):
        response = self.client.post('/api/messages', data='{', content_type='application/json')
        self.assertEqual(response.status_code, 400)
        self.assertIn('error', response.json)

    def test_non_json_is_rejected(self):
        response = self.client.post('/api/messages', data={'message': '项目经历'})
        self.assertEqual(response.status_code, 415)
        self.assertIn('error', response.json)

    def test_oversized_request_has_a_json_error(self):
        response = self.client.post('/api/messages', data=' ' * 32769, content_type='application/json')
        self.assertEqual(response.status_code, 413)
        self.assertIn('error', response.json)


if __name__ == '__main__':
    unittest.main()
