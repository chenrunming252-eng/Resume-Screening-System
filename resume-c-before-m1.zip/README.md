# 赛题 C · 简历助手

当前进度：M0，Web 页面提交项目经历，Python 接口校验与回传。完整要求见 [需求追踪](docs/requirements.md)，架构与边界见 [设计](docs/design.md)。

尚未实现：多轮对话、模型抽取、数据库、简历预览与导出、职位库、投递记录、提醒、反馈推荐、用户认证和服务器部署。当前不能作为比赛完整作品提交。

## 本机运行（PowerShell）

```powershell
cd D:\codex-talkdata\2026-11-02\zhe\outputs\resume-c
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -m flask --app app run --host 127.0.0.1 --port 5000
```

打开 http://127.0.0.1:5000 。用 Ctrl+C 停止服务。无需激活脚本，也不需要模型密钥。仅在本机开发使用；Flask 开发服务器不是比赛部署方案。

当前作者环境为 Python 3.15.1；其他 Python 版本尚未实测。依赖已隔离于本项目 .venv，未修改系统 Python 包。

## 验证

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
```

人工步骤：

1. 输入一段明确的虚构测试经历，例如“负责校园二手交易网站后端，使用 Python，实现商品搜索。”，点击提交，应显示同样内容；只去除两端空白。
2. 输入全空格并提交，应得到提示，不能显示成功。
3. 输入 `<img src=x onerror=alert(1)>`，提交后应显示原样文字，不弹窗、不渲染图片。
4. 刷新页面后文本消失；当前没有持久化。这是本台阶边界。

## 实现依据

- [比赛原文](https://www.kdocs.cn/l/clnX8VV2bu3t)，2026-11-05 全文审读。
- [Flask 安装与虚拟环境](https://flask.palletsprojects.com/en/stable/installation/)。
- [Flask 真实接口测试](https://flask.palletsprojects.com/en/stable/testing/)。
